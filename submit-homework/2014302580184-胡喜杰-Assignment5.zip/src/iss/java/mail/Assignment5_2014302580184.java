/*
 * 1. 注册或选择一个现有邮箱，打开smtp和imap功能
 * 2. 参照javamail api和/或其他网上资料，自行学习imap协议部分
 * 3. 参照IMailService接口的javadoc文档，示例代码，和实验课内容，使用smtp协议和imap协议自行实现IMailService接口，类名随意，但请加上你的学号作为后缀。例如原类名为：Main.java，你的学号是2014302580000，则将其类名改为Main2012302580000.java
 * 4. 如有需要，可以加上任何其他类和/或方法。为所有类与方法编写javadoc文档，并为整个包在peivate范围生成文档
 * 5. 运行HomeworkLoader.Class检查输出是否正确并将输出截屏
 *
 * 学号：2014302580184
 * 姓名：胡喜杰
 * 时间：2015.11.15-2015.11.18
 */

/**
 * Created by 胡喜杰 at 2015.11.18
 */

package iss.java.mail;

import javax.mail.*;
import java.io.IOException;
import java.util.Properties;

/**
 * 定义实现IMailService接口的类
 */
public class Assignment5_2014302580184 implements IMailService{
    private static Properties properties;
    private static Session session;
    private static Transport transport;
    private static Store store;
    private static Folder folder;
    private static String smtpHostName;
    private static String imapHostName;
    private static String username = "javatest184@163.com";
    private static String password = "ntwjbnwdpbbgweym";
    private static String recipient;
    private static String subject;
    private static String text;
    private static SendMail sendMail;
    private static MyAuthenticator myAuthenticator = new MyAuthenticator( "javatest184@163.com","ntwjbnwdpbbgweym");

    /**
     *
     * @param smtpHostName 设置发送服务协议
     */
    public static void setSmtpHostName(String smtpHostName) {
        Assignment5_2014302580184.smtpHostName = smtpHostName;
    }

    /**
     *
     * @return 获得发送服务协议
     */
    public static String getSmtpHostName() {
        return smtpHostName;
    }

    /**
     *
     * @param imapHostName 设置接收服务协议
     */
    public static void setImapHostName(String imapHostName) {
        Assignment5_2014302580184.imapHostName = imapHostName;
    }

    /**
     *
     * @return 获得接收服务协议
     */
    public static String getImapHostName() {
        return imapHostName;
    }

    /**
     *
     * @param username 设置用户名
     */
    public static void setUsername(String username) {
        Assignment5_2014302580184.username = username;
    }

    /**
     *
     * @return 获得用户名
     */
    public static String getUsername() {
        return username;
    }

    /**
     *
     * @param password 设置邮箱密码
     */
    public static void setPassword(String password) {
        Assignment5_2014302580184.password = password;
    }

    /**
     *
     * @return 获得邮箱密码
     */
    public static String getPassword() {
        return password;
    }

    /**
     *
     * @param myAuthenticator 设置用户验证
     */
    public static void setMyAuthenticator(MyAuthenticator myAuthenticator) {
        Assignment5_2014302580184.myAuthenticator = myAuthenticator;
    }

    /**
     *
     * @return 获得用户验证
     */
    public static MyAuthenticator getMyAuthenticator() {
        return myAuthenticator;
    }

    /**
     *
     * @param properties 设置Properties
     */
    public static void setProperties(Properties properties) {
        Assignment5_2014302580184.properties = properties;
    }

    /**
     *
     * @return 获得Properties
     */
    public static Properties getProperties() {
        return properties;
    }

    /**
     *
     * @param session 设置会话
     */
    public static void setSession(Session session) {
        Assignment5_2014302580184.session = session;
    }

    /**
     *
     * @return 获得会话
     */
    public static Session getSession() {
        return session;
    }

    /**
     *
     * @param transport 设置发送端
     */
    public static void setTransport(Transport transport) {
        Assignment5_2014302580184.transport = transport;
    }

    /**
     *
     * @return 获得发送端
     */
    public static Transport getTransport() {
        return transport;
    }

    /**
     *
     * @param store 设置store,存储folder
     */
    public static void setStore(Store store) {
        Assignment5_2014302580184.store = store;
    }

    /**
     *
     * @return 获得store
     */
    public static Store getStore() {
        return store;
    }

    /**
     *
     * @param folder 设置存储邮件的文件夹
     */
    public static void setFolder(Folder folder) {
        Assignment5_2014302580184.folder = folder;
    }

    /**
     *
     * @return 获得文件夹
     */
    public static Folder getFolder() {
        return folder;
    }

    /******************重写IMailService*****************/

    /**
     *
     * @throws MessagingException
     */
    @Override
    public void connect() throws MessagingException{
        new ConnectService(myAuthenticator);
    }

    /**
     *
     * @param recipient 收件人邮箱地址
     * @param subject 邮件主题
     * @param content 邮件正文
     * @throws MessagingException
     */
    @Override
    public void send(String recipient, String subject, Object content) throws MessagingException{
        try{
            sendMail = new SendMail();
            sendMail.SendTextOnlyMail(recipient,subject,content.toString());
        }catch (Exception e){
            e.printStackTrace();
        }
    }

    /**
     *
     * @return 布朗值，指示是否有新邮件
     * @throws MessagingException
     */
    @Override
    public boolean listen() throws MessagingException{
        return folder.hasNewMessages();
    }

    /**
     *
     * @param sender 自动回复的发件人邮箱地址
     * @param subject 自动回复的主题
     * @return 自动回复的内容字符串
     * @throws MessagingException
     * @throws IOException
     */
    @Override
    public String getReplyMessageContent(String sender, String subject) throws MessagingException, IOException {
        try{
            GetMail getMail = new GetMail();
            return getMail.GetReply(sender,subject);
        }catch (Exception e){
            e.printStackTrace();
            return null;
        }
    }

    public static void main(String[]args) {
        try{
            Assignment5_2014302580184 tmp= new Assignment5_2014302580184();
            tmp.smtpHostName = "smtp.163.com";
            tmp.imapHostName = "imap.163.com";
            tmp.username = "javatest184@163.com";
            tmp.password = "ntwjbnwdpbbgweym";
            tmp.connect();
            tmp.recipient = "756414277@qq.com";
            tmp.subject = "JAVATest2";
            tmp.text = "just test";
            tmp.send(recipient,subject,text);
            System.out.println(tmp.listen());
            System.out.println(tmp.getReplyMessageContent(recipient,subject));
        }catch (Exception e){
            e.printStackTrace();
        }
    }
}
