/**
 * Created by 胡喜杰 at 2015.11.18
 */
package iss.java.mail;

import javax.mail.Authenticator;
import javax.mail.PasswordAuthentication;

/**
 * 定义验证类，继承自Authenticator
 */
public class MyAuthenticator extends Authenticator{
    private String username;
    private String password;

    /**
     *
     * @param username 用户名
     * @param password 密码
     */
    public MyAuthenticator(String username,String password) {
        this.username = username;
        this.password = password;
    }

    /**
     *
     * @return 获得用户名
     */
    public String getUserName() {
        return username;
    }

    /**
     *
     * @return 获得密码
     */
    public String getPassword() {
        return  password;
    }

    /**
     *
     * @return 获得身份验证
     */
    @Override
    public PasswordAuthentication getPasswordAuthentication() {
        return new PasswordAuthentication(username,password);
    }
}
