/**
 * Created by 胡喜杰 at 2015.11.18
 */
package iss.java.mail;

import javax.mail.Authenticator;
import javax.mail.Folder;
import javax.mail.Session;
import java.util.Properties;


/**
 * 定义连接服务器的类
 */

public class ConnectService {
    private static Properties properties;

    /**
     *
     * @param authenticator 验证
     */
    public ConnectService(Authenticator authenticator){
        try{
            //初始化properties
            properties = System.getProperties();
            properties.put("mail.smtp.host","smtp.163.com");
            properties.put("mail.imap.host","imap.163.com");
            properties.put("mail.transport.protocol", "smtp");
            properties.put("mail.store.protocol", "imap");
            properties.put("mail.smtp.auth", "true");
            Assignment5_2014302580184.setProperties(properties);


            //创建session
            Assignment5_2014302580184.setSession(Session.getInstance(properties, authenticator));
            //监控邮件发送状态
            //Assignment5_2014302580184.getSession().setDebug(true);
            //通过session得到transport对象
            Assignment5_2014302580184.setTransport(Assignment5_2014302580184.getSession().getTransport());
            //通过session得到store对象
            Assignment5_2014302580184.setStore(Assignment5_2014302580184.getSession().getStore("imap"));
            Assignment5_2014302580184.getStore().connect();
            //得到folder对象
            Assignment5_2014302580184.setFolder(Assignment5_2014302580184.getStore().getFolder("INBOX"));
            Assignment5_2014302580184.getFolder().open(Folder.READ_ONLY);
        }catch (Exception e){
            e.printStackTrace();
        }

    }
}
