/**
 * Created by 胡喜杰 at 2015.11.18
 */
package iss.java.mail;

import javax.mail.Message;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

/**
 * 定义发送邮件类
 */
public class SendMail {
    private Session session;
    private Transport transport;
    private Message message;

    /**
     *
     * @throws Exception
     */
    public SendMail() throws Exception{
        transport = Assignment5_2014302580184.getTransport();
        transport.connect(Assignment5_2014302580184.getSmtpHostName(),Assignment5_2014302580184.getUsername(),
                Assignment5_2014302580184.getPassword());
    }

    /**
     *
     * @param recipient 收件人
     * @param subject 主题
     * @param text 邮件内容
     * @throws Exception
     */
    //发送只含文本的邮件
    public void SendTextOnlyMail(String recipient,String subject,String text) throws Exception{
        //创建邮件对象
        message = new MimeMessage(Assignment5_2014302580184.getSession());
        //指明发件人
        message.setFrom(new InternetAddress(Assignment5_2014302580184.getMyAuthenticator().getUserName()));
        //指明收件人
        message.setRecipient(Message.RecipientType.TO, new InternetAddress(recipient));
        //邮件的标题
        message.setSubject(subject);
        //邮件的内容
        message.setContent(text,"text/html;charset=utf-8");
        //发送邮件
        transport.sendMessage(message,message.getAllRecipients());
        //关闭连接
        transport.close();
    }
}
