/**
 * Created by 胡喜杰 at 2015.11.18
 */
package iss.java.mail;

import javax.mail.Folder;
import javax.mail.Message;
import javax.mail.Multipart;
import javax.mail.search.AndTerm;
import javax.mail.search.FromStringTerm;
import javax.mail.search.SearchTerm;
import javax.mail.search.SubjectTerm;

/**
 * 定义接收邮件类
 */

public class GetMail {
    private Folder folder;

    /**
     *
     * @throws Exception
     */
    public GetMail() throws Exception{
        folder = Assignment5_2014302580184.getFolder();
    }

    /**
     *
     * @param sender 发件人
     * @param subject 主题
     * @return 收到的邮件内容
     * @throws Exception
     */
    public String GetReply(String sender, String subject) throws Exception{
        String reply = "";

/*        Message[] messages = folder.getMessages();
        for(int i=0;i<messages.length;i++) {
            if(messages[i].getSubject().equals(subject)) {
                Multipart multi = (Multipart)messages[i].getContent();
                int k = 0;
                while(k<multi.getCount())
                {
                    if(multi.getBodyPart(k).getContentType().contains("text/plain")){
                        reply += multi.getBodyPart(k).getContent();
                        System.out.println(multi.getBodyPart(k).getContent());
                    }
                    k++;
                }
            }
        }*/

/*        SearchTerm searchTerm = new AndTerm(new FromStringTerm(sender),new SubjectTerm(subject));
        Message[] messages = folder.search(searchTerm);
        for(Message message:messages) {
            if(message.getContentType().contains("TEXT"))  System.out.println(message.getContent());
        }*/

        Message[] messages = folder.getMessages();
        for(Message message:messages) {
            String temp = message.getSubject();
            if(temp.equals(subject)) {
                reply += subject;
            }
        }
        return  reply;
    }
}
